﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebAPiCoreCrudOperation.Migrations
{
    public partial class EmployeeNavigationProperty : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
